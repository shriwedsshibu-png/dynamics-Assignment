clc
clear all
close all

% free vibration of a damped sdof system
% damping 0.4, initial velocity 8 m/s

z = 0.4;                % damping ratio
wn = 5;                 % natural frequency (rad/s)
v0 = 8;                 % initial velocity (m/s)

wd = wn*sqrt(1 - z^2);  % damped natural frequency

t = 0:0.05:5;           % time from 0 to 5 sec

% Divide by wd so the initial velocity is v0.
x = zeros(1,length(t));
for i = 1:length(t)
    x(i) = (v0/wd)*exp(-z*wn*t(i))*sin(wd*t(i));
end

figure(1)
plot(t, x, 'b')
grid on
xlabel('time (s)')
ylabel('x (m)')
title('Damped free vibration, v0 = 8, zeta = 0.40')
