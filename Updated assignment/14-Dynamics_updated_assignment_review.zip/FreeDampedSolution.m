clc
clear all
close all

% free vibration of a damped sdof system
% given initial velocity, zero initial displacement

m = 1000;               % mass (kg)
z = 0.2;                % damping ratio

x0 = 0;                 % initial displacement (m)
v0 = 5;                 % initial velocity (m/s)

wn = 5;                 % natural frequency (rad/s)
wd = wn*sqrt(1 - z^2);  % damped natural frequency

t = 0:0.01:10;          % time from 0 to 10 sec

% free vibration response for x0 = 0
x = zeros(1,length(t));
for i = 1:length(t)
    x(i) = (v0/wd)*exp(-z*wn*t(i))*sin(wd*t(i));
end

figure(1)
plot(t, x, 'b')
grid on
xlabel('time (s)')
ylabel('x (m)')
title('Damped free vibration, x0 = 0, v0 = 5, zeta = 0.20')
