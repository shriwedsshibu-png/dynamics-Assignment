clc
clear all
close all

% Question 3
% Dynamic Amplification Factor for case 1 of problem 2
% m = 1600 kg, k = 60 kN/m, zeta = 2%

m = 1600;
k = 60000;
z = 0.02;               % damping ratio

wn = sqrt(k/m);         % natural frequency

r = 0:0.02:3;           % frequency ratio (forcing freq / natural freq)

% DAF formula for damped sdof under harmonic load
Rd = zeros(1,length(r));
for i = 1:length(r)
    Rd(i) = 1/sqrt((1-r(i)*r(i))^2 + (2*z*r(i))^2);
end

figure(1)
plot(r, Rd, 'b')
hold on
grid on
plot([1 1], [0 30], 'r--')   % resonance line at r = 1
plot([0 3], [1 1], 'k--')    % static limit Rd = 1

xlabel('frequency ratio r')
ylabel('Rd')
title('Dynamic Amplification Factor for 2% damping')
legend('DAF curve', 'resonance', 'static limit')

axis([0 3 0 30])

% maximum value of DAF and where it occurs
[maxRd, loc] = max(Rd);
disp('maximum DAF =')
disp(maxRd)
disp('it occurs at frequency ratio r =')
disp(r(loc))
