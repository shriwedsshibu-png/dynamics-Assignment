clc
clear
close all

% REVIEW ALTERNATIVE ONLY. Confirm the intended DAF definition first.
% Keep this file beside Q2Assignment1.m and Elcentro.mat.
% Q2 computes both cases using Newmark, RK4 and Duhamel.
Q2Assignment1

% Use Case I only: peak effective force = m*peak ground acceleration.
m = mass(1);
force_peak = m*max(abs(ug));
u_static = force_peak/k;

% DAF = peak relative displacement / static displacement under peak force.
DAF_nm = max(abs(u_nm(:,1)))/u_static;
DAF_rk = max(abs(u_rk(:,1)))/u_static;
DAF_dh = max(abs(u_dh(:,1)))/u_static;

disp('Alternative earthquake-normalized DAF for Case I')
disp('Columns: Newmark, RK4, Duhamel')
disp([DAF_nm DAF_rk DAF_dh])
disp('Static displacement under peak effective force (m)')
disp(u_static)

% These are peak ratios for this record, not harmonic resonance factors.
% A uniform change of input units cancels in the ratio for a linear system.
% Record identity and the instructor''s intended definition still matter.
