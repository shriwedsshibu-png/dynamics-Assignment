clc
clear
close all

% Q1: true response spectra, zero initial displacement and velocity.
load('Elcentro.mat')
% Supplied record uses the reference conversion from cm/s^2 to m/s^2.
t = t(:);
ug = 0.01*p(:);
dt = t(2)-t(1);
zeta = [0.01 0.02 0.03 0.04];
T = 0.05:0.05:4;
Sd = zeros(4,length(T));
Sv = zeros(4,length(T));
Sa = zeros(4,length(T));
gamma = 0.5;
beta = 0.25;
m = 1;

for i = 1:4
    for j = 1:length(T)
        w = 2*pi/T(j);
        k = m*w*w;
        c = 2*zeta(i)*m*w;
        % Split input intervals so h is at most T/100.
        ns = ceil(100*dt/T(j));
        if ns < 1
            ns = 1;
        end
        h = dt/ns;
        N = (length(ug)-1)*ns + 1;
        ag = zeros(N,1);
        for n = 1:length(ug)-1
            for s = 1:ns
                r = (n-1)*ns+s;
                ag(r) = ug(n)+(ug(n+1)-ug(n))*(s-1)/ns;
            end
        end
        ag(N) = ug(end);
        u = zeros(N,1);
        v = zeros(N,1);
        acc = zeros(N,1);
        % Newmark average acceleration method
        a0 = 1/(beta*h*h);
        a1 = gamma/(beta*h);
        a2 = 1/(beta*h);
        a3 = 1/(2*beta) - 1;
        a4 = gamma/beta - 1;
        a5 = h*(gamma/(2*beta) - 1);
        ke = k + a0*m + a1*c;
        acc(1) = -ag(1);
        for n = 1:N-1
            force = -m*ag(n+1);
            force = force + m*(a0*u(n) + a2*v(n) + a3*acc(n));
            force = force + c*(a1*u(n) + a4*v(n) + a5*acc(n));
            u(n+1) = force/ke;
            acc(n+1) = a0*(u(n+1)-u(n)) - a2*v(n) - a3*acc(n);
            v(n+1) = v(n) + h*((1-gamma)*acc(n) + gamma*acc(n+1));
        end

        % Scan for peaks using basic loops.
        for n = 1:N
            if abs(u(n)) > Sd(i,j)
                Sd(i,j) = abs(u(n));
            end
            if abs(v(n)) > Sv(i,j)
                Sv(i,j) = abs(v(n));
            end
            aa = acc(n)+ag(n); % absolute mass acceleration
            if abs(aa) > Sa(i,j)
                Sa(i,j) = abs(aa);
            end
        end
    end
end

figure(1)
subplot(3,1,1)
plot(T,Sd')
grid on
ylabel('Sd (m)')
title('Displacement response spectrum')
legend('1%','2%','3%','4%')
subplot(3,1,2)
plot(T,Sv')
grid on
ylabel('Sv (m/s)')
title('Relative velocity response spectrum')
subplot(3,1,3)
plot(T,Sa')
grid on
ylabel('Sa (m/s^2)')
xlabel('Natural period T (s)')
title('Absolute acceleration response spectrum')
