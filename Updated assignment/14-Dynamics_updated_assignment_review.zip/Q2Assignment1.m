clc
clear
close all

% Q2: two SDOF cases, three numerical methods.
% All u, v and a below are relative to the ground.
load('Elcentro.mat')
t = t(:);
ug = 0.01*p(:); % reference assumes input is in cm/s^2
N = length(t);
h = t(2)-t(1);
mass = [1600 800];
k = 60000;
z = 0.02;
gamma = 0.5;
beta = 0.25;
u_nm = zeros(N,2); v_nm = zeros(N,2); a_nm = zeros(N,2);
u_rk = zeros(N,2); v_rk = zeros(N,2); a_rk = zeros(N,2);
u_dh = zeros(N,2); v_dh = zeros(N,2); a_dh = zeros(N,2);

for j = 1:2
    m = mass(j);
    w = sqrt(k/m);
    d = z*w;
    wd = w*sqrt(1-z*z);
    c = 2*m*d;
    ag = ug;
    u = zeros(N,1);
    v = zeros(N,1);
    acc = zeros(N,1);
        % Newmark average acceleration method
        a0 = 1/(beta*h*h);
        a1 = gamma/(beta*h);
        a2 = 1/(beta*h);
        a3 = 1/(2*beta) - 1;
        a4 = gamma/beta - 1;
        a5 = h*(gamma/(2*beta) - 1);
        ke = k + a0*m + a1*c;
        acc(1) = -ag(1);
        for n = 1:N-1
            force = -m*ag(n+1);
            force = force + m*(a0*u(n) + a2*v(n) + a3*acc(n));
            force = force + c*(a1*u(n) + a4*v(n) + a5*acc(n));
            u(n+1) = force/ke;
            acc(n+1) = a0*(u(n+1)-u(n)) - a2*v(n) - a3*acc(n);
            v(n+1) = v(n) + h*((1-gamma)*acc(n) + gamma*acc(n+1));
        end

    u_nm(:,j) = u;
    v_nm(:,j) = v;
    a_nm(:,j) = acc;

    % RK4, with ground acceleration linear within each input interval.
    for n = 1:N-1
        un = u_rk(n,j);
        vn = v_rk(n,j);
        gm = (ug(n)+ug(n+1))/2;
        q1 = vn;
        r1 = -2*d*vn-w*w*un-ug(n);
        q2 = vn+h*r1/2;
        r2 = -2*d*q2-w*w*(un+h*q1/2)-gm;
        q3 = vn+h*r2/2;
        r3 = -2*d*q3-w*w*(un+h*q2/2)-gm;
        q4 = vn+h*r3;
        r4 = -2*d*q4-w*w*(un+h*q3)-ug(n+1);
        u_rk(n+1,j) = un+h*(q1+2*q2+2*q3+q4)/6;
        v_rk(n+1,j) = vn+h*(r1+2*r2+2*r3+r4)/6;
    end

    % Duhamel integral by trapezoidal summation.
    A = 0;
    B = 0;
    for n = 2:N
        f0 = ug(n-1)*exp(d*t(n-1))*cos(wd*t(n-1));
        f1 = ug(n)*exp(d*t(n))*cos(wd*t(n));
        g0 = ug(n-1)*exp(d*t(n-1))*sin(wd*t(n-1));
        g1 = ug(n)*exp(d*t(n))*sin(wd*t(n));
        A = A+h*(f0+f1)/2;
        B = B+h*(g0+g1)/2;
        E = exp(-d*t(n));
        u_dh(n,j) = -E*(A*sin(wd*t(n))-B*cos(wd*t(n)))/wd;
        % Differentiate the integral formula, not sampled displacement.
        v_dh(n,j) = -d*u_dh(n,j) ...
                    -E*(A*cos(wd*t(n))+B*sin(wd*t(n)));
    end
    for n = 1:N
        a_rk(n,j) = -2*d*v_rk(n,j)-w*w*u_rk(n,j)-ug(n);
        a_dh(n,j) = -2*d*v_dh(n,j)-w*w*u_dh(n,j)-ug(n);
    end
end

% Compare methods directly, one figure for each mass case.
for j = 1:2
    figure(j)
    subplot(3,1,1)
    plot(t,u_nm(:,j),'b',t,u_rk(:,j),'r--',t,u_dh(:,j),'k:')
    grid on
    title(['Case ' num2str(j)])
    ylabel('u (m)')
    legend('Newmark','RK4','Duhamel')
    subplot(3,1,2)
    plot(t,v_nm(:,j),'b',t,v_rk(:,j),'r--',t,v_dh(:,j),'k:')
    grid on
    ylabel('v (m/s)')
    subplot(3,1,3)
    plot(t,a_nm(:,j),'b',t,a_rk(:,j),'r--',t,a_dh(:,j),'k:')
    grid on
    ylabel('a (m/s^2)')
    xlabel('Time (s)')
end

% Peak values: columns are Newmark, RK4, Duhamel.
for j = 1:2
    disp(['Case ' num2str(j) ': peak relative displacement (m)'])
    disp([max(abs(u_nm(:,j))) max(abs(u_rk(:,j))) max(abs(u_dh(:,j)))])
end
